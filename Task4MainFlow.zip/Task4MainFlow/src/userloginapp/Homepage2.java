package userloginapp;

import javax.swing.*;

public class Homepage2 extends JFrame {
    public Homepage2() {
        setTitle("Homepage");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel welcome = new JLabel("Welcome to the Homepage!", SwingConstants.CENTER);
        add(welcome);
    }
}
