package userloginapp;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class Homepage extends JFrame {

    private JButton viewProfileButton;
    private JButton settingsButton;
    private JButton logoutButton;
    private JLabel titleLabel;
    private JLabel greetingLabel;

    public Homepage() {
        initComponents();
    }

    private void initComponents() {
        titleLabel = new JLabel("Welcome to the Homepage", SwingConstants.CENTER);
        greetingLabel = new JLabel("Hello, User!", SwingConstants.CENTER);

        viewProfileButton = new JButton("View Profile");
        settingsButton = new JButton("Settings");
        logoutButton = new JButton("Logout");

        titleLabel.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 20));
        greetingLabel.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 14));

        logoutButton.addActionListener(this::logoutButtonActionPerformed);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Homepage");

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(titleLabel)
                .addComponent(greetingLabel)
                .addComponent(viewProfileButton, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                .addComponent(settingsButton, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                .addComponent(logoutButton, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(titleLabel)
                .addComponent(greetingLabel)
                .addGap(10)
                .addComponent(viewProfileButton)
                .addComponent(settingsButton)
                .addComponent(logoutButton)
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispose();
        new LoginForm().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Homepage().setVisible(true));
    }
}
